flag="$(echo 'ebgnpvbarf' | tr 'A-Za-z' 'N-ZA-Mn-za-m')"
echo "flag: $flag" >> ~/.bash_history
history -r ~/.bash_history

rm -rf entra
mkdir entra
cd entra
mkdir a
cd a
mkdir esta
cd esta
mkdir carpeta
cd carpeta
echo "yn onaqern nfgn ra gh uvfgbevny" | tr 'A-Za-z' 'N-ZA-Mn-za-m' > readme.txt

echo "cierra tu terminal y vuelve a abrir"
echo "luego entra a las carpetas..."